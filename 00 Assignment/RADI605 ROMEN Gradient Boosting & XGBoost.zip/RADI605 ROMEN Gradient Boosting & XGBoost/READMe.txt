ROMEN SAMUEL WABINA | Student No. 6536435
PhD student, Data Science for Healthcare and Clinical Informatics 
Clinical Epidemiology and Biostatistics, Faculty of Medicine - Ramathibodi Hospital 
Mahidol University

RADI605 Modern Machine Learrning
Assignment for Gradient Boosting & XGBoost:

├── RADI605 ROMEN Gradient Boosting & XGBoost
│   ├── data
│   │	  ├── Breast_Cancer.csv
│   │	  ├── leukemia.csv
│   ├── figures
│   │	  ├── fig.PNG
│   │	  ├── fig1.JPG
│   │	  ├── fig1.PNG
│   │	  ├── fig2.PNG
│   │	  ├── final.PNG
│   │	  ├── tree.PNG
│   │	 
│   └── scripts
│	  ├── Question 1.ipynb
│	  ├── Question 2.ipynb


You may also access the assignment through this GitHub Link:
https://github.com/rrwabina/RADI605