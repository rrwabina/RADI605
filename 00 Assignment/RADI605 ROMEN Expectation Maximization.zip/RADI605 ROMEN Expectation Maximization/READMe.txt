ROMEN SAMUEL WABINA | Student No. 6536435
PhD student, Data Science for Healthcare and Clinical Informatics 
Clinical Epidemiology and Biostatistics, Faculty of Medicine - Ramathibodi Hospital 
Mahidol University

RADI605 Modern Machine Learrning
Assignment for Expectation Maximization:

├── RADI605 ROMEN Expectation Maximization
│   ├── data
│	  ├── Impute-data.csv
│   │	 
│   │	  
│   └── scripts
│	  ├── RADI605 Expectation Maximization Assignment.ipynb

You may also access the assignment through this GitHub Link:
https://github.com/rrwabina/RADI605/tree/main/00%20Assignment