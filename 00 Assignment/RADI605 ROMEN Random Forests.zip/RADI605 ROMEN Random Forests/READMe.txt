ROMEN SAMUEL WABINA | Student No. 6536435
PhD student, Data Science for Healthcare and Clinical Informatics 
Clinical Epidemiology and Biostatistics, Faculty of Medicine - Ramathibodi Hospital 
Mahidol University

RADI605 Modern Machine Learrning
Assignment for Random Forests:

├── Semi-Supervised Learning
│   ├── data
│   │	  ├── sobar-72.csv
│   │	  ├── ThoraricSurgery.csv
│   │	 
│   │	 
│   └── scripts
│	  ├── RADI605 Random Forests Assignment.ipynb


You may also access the assignment through this GitHub Link:
https://github.com/rrwabina/RADI605/tree/main/00%20Assignment